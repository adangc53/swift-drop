//
//  ConsultasController.swift
//  consultorio movil
//
//  Created by Tecnologico Roque on 11/4/19.
//  Copyright © 2019 Tecnologico Roque. All rights reserved.
//

import UIKit
import SQLite3
class ConsultasController: UIViewController {
    var consultas = [consulta]()
 var db: OpaquePointer? // Apuntador a la base de datos
    
    @IBOutlet weak var tffolio: UITextField!
    
    @IBOutlet weak var lblcedula: UITextField!
    
    @IBOutlet weak var noseguro: UITextField!
    
    @IBOutlet weak var etpresion: UITextField!
    
    @IBOutlet weak var etprescr: UITextField!
    @IBOutlet weak var etdiagno: UITextField!
    @IBOutlet weak var etestatura: UITextField!
    @IBOutlet weak var peso: UITextField!
    @IBOutlet weak var noexpediente: UITextField!
    var folio:String? = ""
    var cedula:String? = ""
    var nosegu:String? = ""
    var noexp:String? = ""
    var presion:String? = ""
    var prescr: String? = ""
    var diagno:String?  = ""
    var estatu:String? = ""
    var pe:String? = ""
    
    
    func leer(){
         folio = tffolio.text?.trimmingCharacters(in: .whitespacesAndNewlines)
         cedula = lblcedula.text?.trimmingCharacters(in: .whitespacesAndNewlines)
         nosegu = noseguro.text?.trimmingCharacters(in: .whitespacesAndNewlines)
         noexp=noexpediente.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        presion = etpresion.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        prescr = etprescr.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        diagno = etdiagno.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        estatu = etestatura.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        pe = peso.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        
    }
    @IBAction func btninserta(_ sender: Any) {
      leer()
        let fol : NSString = folio! as NSString
        let cedu: NSString  = cedula! as NSString  //pablo estuvo aqui
        let noseg: NSString = nosegu! as NSString
        var stmt:OpaquePointer?
        let noex : NSString = noexp! as NSString
        let pres : NSString =  presion! as NSString
        let prescripsion : NSString = prescr! as NSString
        let diagnostico : NSString =  diagno! as NSString
        let estatura : NSString = estatu! as NSString
        let pesos : NSString = pe! as NSString
        
        
        let sentencia = "INSERT INTO Consultas(folio,cedula,noseguro,noexpediente,presion,prescripcion,diagnostico,estatura,peso) values (?,?,?,?,?,?,?,?,?)"
        
        // Prepara la sustitución de los 2 values del insert
        if sqlite3_prepare(db, sentencia, -1, &stmt, nil) == SQLITE_OK{
            sqlite3_bind_text(stmt, 1, fol.utf8String, -1, nil)
            sqlite3_bind_text(stmt,2,cedu.utf8String, -1, nil)
            sqlite3_bind_text(stmt,3,noseg.utf8String, -1, nil)
            sqlite3_bind_text(stmt,4, noex.utf8String, -1, nil)
            sqlite3_bind_text(stmt,5, pres.utf8String,-1, nil)
            sqlite3_bind_text(stmt,6, prescripsion.utf8String,-1,nil)
            sqlite3_bind_text(stmt,7,diagnostico.utf8String,-1,nil)
            sqlite3_bind_text(stmt,8, estatura.utf8String, -1,nil)
            sqlite3_bind_text(stmt,9, pesos.utf8String,-1,nil)
            
            
        }
        // Manda ejecutar el insert y si presenta error despliega una alerta
        if sqlite3_step(stmt) != SQLITE_DONE{
            let errmsg = String(cString: sqlite3_errmsg(db)!)
            showAlerta(Titulo: "Error Insertar", Mensaje: errmsg)
            return
        }
        tffolio.text = ""
        lblcedula.text = ""
        noseguro.text = ""
        noexpediente.text = ""
        etpresion.text = ""
        etprescr.text = ""
        etdiagno.text = ""
        etestatura.text = ""
        peso.text = ""
    }
    func showAlerta(Titulo: String, Mensaje: String    ){
        // Crea la alerta
        let alert = UIAlertController(title: Titulo, message: Mensaje, preferredStyle: UIAlertController.Style.alert)
        // Agrega un boton
        alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
        // Muestra la alerta
        self.present(alert, animated: true, completion: nil)
    }
    
    
    @IBAction func btnconsulta(_ sender: UIButton) {
        consultas.removeAll()
        let query = "Select folio,cedula,noseguro,noexpediente from Consultas" //pablo estuvo aqui
        //declaracion de var
        var stmt : OpaquePointer?
        if(sqlite3_prepare(db, query, -1, &stmt, nil) != SQLITE_OK){
            let errmsg = String(cString: sqlite3_errmsg(db)!)
            showAlerta(Titulo: "Error Consultar", Mensaje: errmsg)
            return
        }
        while (sqlite3_step(stmt) == SQLITE_ROW){
            let fol = String(cString:sqlite3_column_text(stmt, 0))
            let cedu = String(sqlite3_column_int(stmt, 1))//pablo estuvo aqui
            let nos = String(sqlite3_column_int(stmt, 2))
            let noexp = String(sqlite3_column_int(stmt, 3))
           // print(fol)
            consultas.append(consulta(folio: fol, cedula: cedu,noseguro: nos, noexpediente: noexp))//pablo estuvo aqui
            
        }
    }//consulta
    
    @IBAction func btnborrar(_ sender: UIButton) {
       let folio = tffolio.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        let fol : NSString = folio! as NSString
        var stmt:OpaquePointer?
        let sentencia = "DELETE FROM Consultas WHERE folio = ?;"
        
        if sqlite3_prepare(db, sentencia, -1, &stmt, nil) == SQLITE_OK{
            sqlite3_bind_text(stmt, 1,fol.utf8String , -1, nil)
            if sqlite3_step(stmt) == SQLITE_DONE {
                print("Successfully deleted row.")
            } else {
                print("Could not delete row.")
            }
        } else {
            print("DELETE statement could not be prepared")
        }
        
    }//borrar
    
    
    @IBAction func btnactualizar(_ sender: UIButton) {
        let folio = tffolio.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        let fol : NSString = folio! as NSString
        let cedula = lblcedula.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        let cedu: Int32 = Int32(cedula!) as! Int32 //pablo estuvo aqui
        let nosegu = noseguro.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        let noseg: Int32 = Int32(nosegu!) as! Int32
      
        let noexp = noexpediente.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        let noex: Int32 = Int32(noexp!) as! Int32
        var stmt:OpaquePointer?
        let sentencia = "UPDATE Consultas SET cedula=?,noseguro=?,noexpediente=? WHERE folio = ?;"
        
        if sqlite3_prepare(db, sentencia, -1, &stmt, nil) == SQLITE_OK{
            
            sqlite3_bind_int(stmt,1,cedu)
            sqlite3_bind_int(stmt,2,noseg)
            sqlite3_bind_int(stmt,3,noseg)
            sqlite3_bind_text(stmt, 4,fol.utf8String , -1, nil)
            if sqlite3_step(stmt) == SQLITE_DONE {
                print("Successfully update row.")
            } else {
                print("Could not update row.")
            }
        } else {
            print("UPDATE statement could not be prepared")
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let fileURL=try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
            .appendingPathComponent("PacientesDatabase.sqlite")
        // Abre la base de datos y la asigna a db que es apuntador
        if sqlite3_open(fileURL.path, &db) != SQLITE_OK{
            showAlerta(Titulo: "Base de Datos", Mensaje: "Error al abrir Base de Datos")
        }
        // Si no existe la tabla de Producto la CREA
        if sqlite3_exec(db, "CREATE TABLE IF NOT EXISTS Consultas(folio  TEXT PRIMARY KEY, cedula INTEGER,noseguro INTEGER, noexpediente INTEGER,presion TEXT, peso TEXT,estatura TEXT,diagnostico TEXT,prescripcion TEXT)", nil, nil, nil) != SQLITE_OK{
            let errmsg = String(cString: sqlite3_errmsg(db)!)
            showAlerta(Titulo: "Error al Crear Tabla", Mensaje: errmsg)
        }

        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "push"){
            let tableSegue = segue.destination as! TableViewController
            tableSegue.consultas = consultas
        }
            

}

}

