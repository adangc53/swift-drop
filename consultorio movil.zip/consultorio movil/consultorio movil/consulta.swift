//
//  consulta.swift
//  consultorio movil
//
//  Created by Tecnologico Roque on 11/4/19.
//  Copyright © 2019 Tecnologico Roque. All rights reserved.
//

import Foundation
class consulta {
    //declaramos las variables locales de las variables
    var folio : String
    var cedula : String
    var noseguro : String
    var noexpediente : String
    //Para evitar concatenaciones podnremos string
    
    //Declaramos el init
    init(folio: String, cedula: String, noseguro: String, noexpediente: String ){
        //este viene siendo como el this de kotlin
        self.folio = folio
        self.cedula = cedula
        self.noseguro = noseguro
        self.noexpediente = noexpediente
        //print(fol)
            }
}
