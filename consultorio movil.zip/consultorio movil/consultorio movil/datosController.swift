//
//  datosController.swift
//  consultorio movil
//
//  Created by Tecnologico Roque on 12/2/19.
//  Copyright © 2019 Tecnologico Roque. All rights reserved.
//

import UIKit
import SQLite3
class datosController: UIViewController {
 let key = "104"
 var db: OpaquePointer?
    
    struct Datarest: Decodable {
        let folio:String
        let cedula:String
        let noSeguro:String// si no se utiliza poner null si no marca error
        let noExpediente:String
        let presion:String
        let peso:String
        let estaruta:String
        let diagnostico:String
        let prescripcion:String
        let fecha:String
        
    }
    @IBAction func datos(_ sender: Any ) {
        let  datos_enviados : NSMutableDictionary = [:]
        let url = URL(string: "http://192.168.64.2/wsswift/getconsultas.php")!
        //convertimos la constante url a tipo URLRequest
        var request = URLRequest(url: url)
        
        //establecemos las cabeceras de la petición JSON estándar
        request.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Accept")
        request.httpMethod = "POST"
        
         datos_enviados["cedula"] = "104"
          request.httpBody = try! JSONSerialization.data(withJSONObject: datos_enviados)
        let tarea  = URLSession.shared.dataTask(with: request){(  datos, respuesta, error)in
            if error != nil{
                print(error!)
            }else{
                do{
                    
                    
                    
                    
                   // let json = try JSONSerialization.jsonObject(with: datos!, options: JSONSerialization.ReadingOptions.mutableContainers) as! [String:Any]
                    var contries = try JSONDecoder().decode([Datarest].self, from: datos!)
                    for contries in contries{
                        let folio = contries.folio
                        let cedula = contries.cedula
                        let nosegs = contries.noSeguro
                        let  noexp = contries.noExpediente
                        let estaturas = contries.estaruta
                        let presion = contries.presion
                        let peso = contries.peso
                        let prescrip = contries.prescripcion
                        let diag = contries.diagnostico
                        let fechas = contries.fecha
                        
                        let fol : NSString = folio as NSString
                        let cedu: NSString = cedula as NSString
                        let noseg: NSString = nosegs as NSString
                        var stmt:OpaquePointer?
                        let noex : NSString = noexp as NSString
                        let pres : NSString =  presion as NSString
                        let prescripsion : NSString = prescrip as NSString
                        let diagnostico : NSString =  diag as NSString
                        let estatura : NSString = estaturas as NSString
                        let pesos : NSString = peso as NSString
                        let fecha : NSString = fechas as NSString
                        
                        let sentencia = "INSERT INTO Consultas(folio,cedula,noseguro,noexpediente,presion,prescripcion,diagnostico,estatura,peso) values (?,?,?,?,?,?,?,?,?)"
                        
                        if sqlite3_prepare(self.db, sentencia, -1, &stmt, nil) == SQLITE_OK{

                            sqlite3_bind_text(stmt, 1, fol.utf8String, -1, nil)
                            sqlite3_bind_text(stmt,2,cedu.utf8String,-1, nil)
                            sqlite3_bind_text(stmt,3,noseg.utf8String,-1, nil)
                            sqlite3_bind_text(stmt,4, noex.utf8String,-1, nil)
                            sqlite3_bind_text(stmt,5, pres.utf8String,-1, nil)
                            sqlite3_bind_text(stmt,6, prescripsion.utf8String,-1,nil)
                            sqlite3_bind_text(stmt,7,diagnostico.utf8String,-1,nil)
                            sqlite3_bind_text(stmt,8, estatura.utf8String, -1,nil)
                            sqlite3_bind_text(stmt,9, pesos.utf8String,-1,nil)
                            
                            
                        }
                        if sqlite3_step(stmt) != SQLITE_DONE{
                            let errmsg = String(cString: sqlite3_errmsg(self.db)!)
                            self.showAlerta(Titulo: "Error Insertar", Mensaje: errmsg)
                            return
                        }
                    }
                    
                }catch{
                    print("el procesamiento del json tuvo un error")
                }
            }
            
        }
        tarea.resume()
        

    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let fileURL=try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
            .appendingPathComponent("PacientesDatabase.sqlite")
        // Abre la base de datos y la asigna a db que es apuntador
        if sqlite3_open(fileURL.path, &db) != SQLITE_OK{
            showAlerta(Titulo: "Base de Datos", Mensaje: "Error al abrir Base de Datos")
        }
        // Si no existe la tabla de Producto la CREA
        if sqlite3_exec(db, "CREATE TABLE IF NOT EXISTS Consultas(folio  TEXT PRIMARY KEY, cedula TEXT,noseguro TEXT, noexpediente TEXT,presion TEXT, peso TEXT,estatura TEXT,diagnostico TEXT,prescripcion TEXT)", nil, nil, nil) != SQLITE_OK{
            let errmsg = String(cString: sqlite3_errmsg(db)!)
            showAlerta(Titulo: "Error al Crear Tabla", Mensaje: errmsg)
        }
        
        
    }
    func showAlerta(Titulo: String, Mensaje: String    ){
        // Crea la alerta
        let alert = UIAlertController(title: Titulo, message: Mensaje, preferredStyle: UIAlertController.Style.alert)
        // Agrega un boton
        alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
        // Muestra la alerta
        self.present(alert, animated: true, completion: nil)
    }

  
}
