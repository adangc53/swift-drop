//
//  ViewController.swift
//  consultorio movil
//
//  Created by Tecnologico Roque on 9/30/19.
//  Copyright © 2019 Tecnologico Roque. All rights reserved.
//

import UIKit
import SQLite3
class ViewController: UIViewController {
     var db: OpaquePointer? // Apuntador a la base de datos
    
    
    @IBAction func btnConsultas(_ sender: UIButton) {
    }
    
    
    @IBAction func btnEstadisticas(_ sender: Any) {
    }
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
            }
    func showAlerta(Titulo: String, Mensaje: String    ){
        // Crea la alerta
        let alert = UIAlertController(title: Titulo, message: Mensaje, preferredStyle: UIAlertController.Style.alert)
        // Agrega un boton
        alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
        // Muestra la alerta
        self.present(alert, animated: true, completion: nil)
    }


}

